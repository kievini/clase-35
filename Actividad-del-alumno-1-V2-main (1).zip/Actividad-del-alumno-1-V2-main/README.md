# C35_Pelota con movimiento sincrónico
Actividad del alumno 1
